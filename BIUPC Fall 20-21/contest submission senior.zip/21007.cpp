#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a;
    cin>>a;
    if(a>=43&&a<=46)
    {
        cout<<"Junior division"<<endl;
    }
    else if(a<=42&&a>=39)
    {
        cout<<"Senior division"<<endl;
    }
        else
        {
            cout<<"Out of the division"<<endl;
        }

    return 0;
}