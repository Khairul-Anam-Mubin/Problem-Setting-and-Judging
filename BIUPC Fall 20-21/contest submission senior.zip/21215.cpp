#include <iostream>
using namespace std;

int main()
{
    int a, b,t;
    cin>>t;
    for(int i = 1; i <= t; i++)
    {
        cin>>a>>b;
        int ct = 0;
        for(int i = 0 ; i < b; i+=2)
        {
            if((i^(i+1))>=1)ct++;
        }

        printf("%d\n",ct);
    }


    return 0;
}