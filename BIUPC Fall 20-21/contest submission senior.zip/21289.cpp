#include<stdio.h>
#include<math.h>
#define PI 3.14159
int main()
{
    int Tks,T;
    scanf("%d",&Tks);
    T=1;
    while(T<=Tks)
    {
    double t,c,s,h;
    int a,b;

    scanf("%d %d",&a,&b);

    h = 1.732050808*(b-a); 
    c = PI*(h/2)*(h/2);
    t = h*(a+b)/2;

    s = t-c;
    printf("%lf\n",s);

    T++;
    }

    return 0;

}