#include<bits/stdc++.h>
using namespace std;
int main()
{
    int l,r,cnt=0,i;
    cin>>l>>r;
    for(i=l;i<=r;i++)
    {
        if(i%2==1)
        {
            cnt=cnt+1;
        }
    }
    cout<<cnt<<endl;

    return 0;
}