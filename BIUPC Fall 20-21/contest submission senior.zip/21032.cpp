#include<bits/stdc++.h>
using namespace std;
int main()
{
    int A;
    cin >> A;
    if(A==39 || A==40 || A==41 || A==42)
        cout << "Senior division" << endl;

    else if(A==43 || A==44 || A==45 || A==46)
        cout << "Junior division" << endl;

    else
        cout << "Out of the division" << endl;
}