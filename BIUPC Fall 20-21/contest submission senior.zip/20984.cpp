#include <iostream>

using namespace std;

int main()
{
    int A;
    cin>>A;
    if(A>=39 && A<43){
        cout<<"Senior division"<<endl;
    }
    else if(A>=43 && A<=46)
    {
        cout<<"Junior division"<<endl;
    }
    else
    {
        cout<<"Out of the division"<<endl;
    }
}