#include<iostream>
#include<cmath>


using namespace std;

int main(){

    int Test;
    double pi =2*acos(0.0);

    cin>>Test;

    for(int i=0;i<Test;i++){
        int a,b;
        double r;
        float area;

        cin>>a>>b;

        r=((a*b)*1.00)/(a+b);

        area = ((a+b)*r)-(pi*r*r)*1.00;

        cout.precision(6);
        cout<<area<<endl;

    }

    return 0;
}