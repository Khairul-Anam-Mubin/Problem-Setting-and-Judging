#include <bits/stdc++.h>

using namespace std;


double round(double var)
{
    double value = (int)(var * 1000000 + .5);
    return (double)value / 1000000;
}


int main(){

        std::cout << std::setprecision(16);

    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    int T;
    cin>>T;

    double r, tra, cir;

    for(int t=1;t<=T;t++){


        int a,b;
        cin>>a>>b;

        r = (a*b*1.0)/((a+b)*1.0);

        tra = ((a+b)/2.0)*r*2;
        cir = 2*acos(0.0) * r*r;


        cout<<round(tra-cir)<<endl;

    }

    return 0;
}