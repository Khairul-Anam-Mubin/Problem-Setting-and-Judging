#include<iostream>

using namespace std;


int main(){

    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    int num;

    while (cin>>num){

        if (num>=39 && num<=42){
            cout<<"Senior division"<<endl;
        }else if(num>=43 && num<=46){
            cout<<"Junior division"<<endl;
        }else{
            cout<<"Out of the division"<<endl;
        }

    }

    return 0;
}