#include<bits/stdc++.h>
using namespace std;
#define pi 2*acos(0.0)
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        double a,b,c,d,e,f,g,h;
   cin>>a>>b;
   c=(a*b)/(a+b);
   d=2*c;
   e=((a+b)*d)/2;
   f=pi*(c*c);
   g=abs(e-f);
   printf("%f\n",g);

    }




}