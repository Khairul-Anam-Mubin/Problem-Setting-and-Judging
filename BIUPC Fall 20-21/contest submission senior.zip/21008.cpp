#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    if(n>=43 && n<=46)
    cout<<"Junior division"<<endl;
    else if(n>=39 && n<=42)
    cout<<"Senior division"<<endl;
    else 
    cout<<"Out of the division"<<endl;
    
    return 0;
}