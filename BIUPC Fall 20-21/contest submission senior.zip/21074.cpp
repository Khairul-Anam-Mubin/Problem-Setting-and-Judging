#include<iostream>
#include<cstdio>

using namespace std;


int main(){

    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    long long int a,b;

    while (cin>>a>>b){

        long long int c = (b-a)/2;

        if(a%2!=0 || b%2!=0){
            c+=1;
        }

        cout<<c<<endl;

    }

    return 0;
}