#include<bits/stdc++.h>
using namespace std;
#define PI 2 * acos(0.0)
int main()
{
    int t;
    cin>>t;
    while(t--){
        double a,b;
        cin>>a>>b;
        double r = ((a*b))/(a+b);
        double A = PI * (r*r);
        double ans = (a*b) - A;
        printf("%.6lf\n",ans);
    }
    return 0;
}