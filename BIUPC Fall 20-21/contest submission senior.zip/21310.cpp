#include <iostream>
using namespace std;
#define ll long long
int F[100000];
void Fr(){
    int ct;
    F[1]=0;
    for(int i = 2 ; i < 10001; i++ ){
          ct = 0;
        for(int k = 0 ; k < i; k+=2)
        {
            if((k^(k+1))>=1)ct++;
        }
        //cout<<i<<"-->"<<ct<<endl;
        F[i]+=ct;

    }
    //return;
}

int main()
{
    int a, b,t;
    Fr();
    cin>>t;
    for(int i = 1; i <= t; i++)
    {
        cin>>a>>b;

        printf("%d\n",F[b]);
    }


    return 0;
}