#include<bits/stdc++.h>
using namespace std;
int main(){

    int a;
    cin>>a;
    if(a>=39 and a<=42){
        cout<<"Senior division"<<endl;
    }
    else if(a>=43 and a<=46){
        cout<<"Junior division"<<endl;
    }
    else {
        cout<<"Out of the division"<<endl;
    }
}