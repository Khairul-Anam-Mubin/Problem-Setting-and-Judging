#include<iostream>
using namespace std;
int main()
{
    int L,R,i,count=0;
    cin>>L>>R;
    for(i=L;i<=R;i++)
    {
        if(i%2==1)
        {
            count+=1;
        }

    }
    cout<<count<<endl;
}