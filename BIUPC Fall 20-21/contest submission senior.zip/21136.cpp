#include <iostream>

using namespace std;

int main()
{
    int L,R,cnt=0;
    
    cin>>L;
    cin>>R;
    for(int i=L;i<=R;i++){
        if(i%2 != 0){
            cnt++;
        }
    }
    cout<<cnt;
   
}