#include<bits/stdc++.h>
using namespace std;
int xorPairCount(int arr[], int n, int x)
{
    int result = 0;
    unordered_set<int> s;
 
    for (int i=0; i<n ; i++)
    {
        
        if (s.find(x^arr[i]) != s.end())
            result++;
        s.insert(arr[i]);
    }
    return result;
}
int main()
{
    
    int i,b,x,t;int arr[100] ;
    cin>>t;
    while(t--){
    cin>>x>>b;
    for(i=0;i<=b;i++)
      arr[i]=i;
    cout<< xorPairCount(arr, b+1, x)<<endl;}
    return 0;
}