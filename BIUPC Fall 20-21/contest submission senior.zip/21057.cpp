#include<bits/stdc++.h>
using namespace std;
int main(){
    int L, R;
    cin>>L>>R;
    int ans = ((R-L)/2)+1;
    cout<<ans<<endl;
    return 0;
}