///*    ***Bismillahir Rahmanir Rahim***   */

/*
 Algorithm Used: 
*/
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

#define MAX 1000005
#define precision(a) fixed << setprecision(a)
#define mod 1000000007
int main()
{
    //O_O ;
    ll n;
    cin >> n;
    if (n >= 39 && n <= 42)
        cout << "Senior division" << endl;
    else if (n <= 45 && n >= 42)
        cout << "Junior division" << endl;
    else
        cout << "Out of the division" << endl;

    return 0;
}