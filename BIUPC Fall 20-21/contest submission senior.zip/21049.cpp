#include<bits/stdc++.h>
using namespace std;
int main()
{
    int i,l,r,c=0;
    cin>>l>>r;
    for(i=l;i<=r;i++)
    {
        if(i%2!=0)c++;
    }
    cout<<c<<endl;
    return 0;
}