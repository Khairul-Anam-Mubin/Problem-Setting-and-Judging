#include<bits/stdc++.h>
using namespace std;
int main()
{
    int L, R, cont=0;
    cin >> L >> R;
    for(int i=L; i<=R; i++)
    {
        if(i%2!=0)
            cont++;
    }
    cout << cont << endl;
}