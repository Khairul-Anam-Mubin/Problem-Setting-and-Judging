#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b;
    while(cin>>a>>b){
          if(a>b)swap(a,b);
    int ct = 0;
    for(int i = a; i <= b; i++){
        if(i%2==1)ct++;
    }
    cout<<ct<<endl;
          }


}