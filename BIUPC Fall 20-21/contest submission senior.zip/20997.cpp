#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b;
    while(cin>>a){
        if(a>=39 && a<= 43)cout<<"Senior division"<<endl;
    else if(a>= 44 && a<= 46)cout<<"Junior division"<<endl;
    else cout<<"Out of the division"<<endl;
    }

}