#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
    int t;
    cin>>t;
    while(t--){
        ll n;
        int x;
        cin>>n>>x;
        cout<<(x+1)/2<<endl;
    }
    return 0;
}