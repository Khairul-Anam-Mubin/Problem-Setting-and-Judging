#include<iostream>
using namespace std;

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n, m, temp, flag;
    cin >> n >> m;

    int v[n];
    int ans[m];

    for(int i = 0; i < n; i++)
    {
        cin >> v[i];
    }

    for(int i = 0; i < m; i++)
    {
        flag = 0;
        cin >> temp;

        for(int j = 0; j < n; j++)
        {
            if(temp <= v[j])
            {
                ans[i] = j + 1;
                v[j] = v[j] - temp;
                flag = 1;
                break;
            }
        }

        if(flag == 0) ans[i] = 0;
    }

    for(int i = 0; i < m; i++) cout << ans[i] << endl;
    return 0;
}