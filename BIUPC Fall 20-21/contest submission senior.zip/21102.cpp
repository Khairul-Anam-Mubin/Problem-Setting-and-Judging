#include<bits/stdc++.h>
using namespace std;
int main()
{
    int L, R;
    cin>>L>>R;
    int ans = ((R-L)/2);
    if(R % 2 != 0 || L % 2 != 0)
    {
        ans += 1 ;
    }
    cout<<ans<<endl;
    return 0;
}