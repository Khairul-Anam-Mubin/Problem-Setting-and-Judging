#include<bits/stdc++.h>
using namespace std;
int xorPairCount(int i, int n, int x)
{
    int result = 0;
    unordered_set<int> s;
 
    for (int i=0; i<n ; i++)
    {
        
        if (s.find(x^i) != s.end())
            result++;
        s.insert(i);
    }
    return result;
}
int main()
{
    
    int i,b,x,u,t;
    cin>>t;
    while(t--){
    cin>>x>>b;
    if(b>=x){      
    for(i=0;i<=b;i++)
     
    u = xorPairCount(i, b+1, x);
    cout<<u<<endl;
    }
    
    else 
      break;
    }
    return 0;
}