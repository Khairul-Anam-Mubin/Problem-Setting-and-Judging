#include <bits/stdc++.h>
using namespace std;
int main(){
    int a,b,t;
    cin>>t;
    for(int i = 1; i <= t; i++){
         cin>>a>>b;
    double pi = 2 * acos(0.0),c,d;

    c = a*b;
    d = a+b;
    printf("%lf\n",c-((c/d)*(c/d)*pi));
    }

}