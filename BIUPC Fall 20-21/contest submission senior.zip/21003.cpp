#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);
    if(39<=a && a<=42)
        printf("Senior division\n");
    else if(43<=a && a<=46)
        printf("Junior division\n");
    else
        printf("Out of the division\n");

    return 0;
}