#include<stdio.h>
int main()
{
    printf("Be brave.");
    return 0;
}