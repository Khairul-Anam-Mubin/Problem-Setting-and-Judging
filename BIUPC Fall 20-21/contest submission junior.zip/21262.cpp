#include<bits/stdc++.h>
using namespace std;
int main()
{
    int T,N;
    cin >> T;

        for (int N=1;N<=100;N++)
        {
            cin>> N;

            if(N%18==0)
            {
                cout << "YES"<<endl;
            }

            else

            {
                cout << "NO"<<endl;
            }

        }
    return 0;
}