#include <stdio.h>
#include <string.h>
int main()
{
  int i;
  int flag = 0;
  for(i = 0 ; i < 5 ; i++) {
      char a[100];
      int length;
      gets(a);
      length = strlen(a);
      if(length != 5) {
        flag = 1;
      }
  }

  if(flag == 1) {
    printf("Pocha Dim\n");
  } else {
    printf("Mim\n");
  }

  return 0;
}