#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define yes "YES"
#define no "NO"
#define pb push_back
#define si size()
#define in " "
#define mone "-1"
#define zero "0"
#define one "1"
#define PI acos(-1)
//ll lcm(ll a,ll b)
//{
//    return (a*b/(__gcd(a,b)));
//}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
//    ll t;
//    cin >> t;
//    while (t--)
//    {
ll flag=0;
        string s;
        for(ll i=0;i<5;i++)
        {
             cin>>s;
             if(s.size()==5)
                flag++;
        }

        if(flag==5)
            cout<<"Mim"<<endl;
        else
            cout<<"Pocha Dim"<<endl;
   // }
    return 0;
}