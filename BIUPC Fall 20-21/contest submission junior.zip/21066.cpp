#include<bits/stdc++.h>
using namespace std;
int main()
{
    int l,r,count=0;
    scanf("%d%d",&l,&r);
    for(int i=l;i<=r;i++)
    {
        if(i%2!=0)
        {
            count++;
        }
    }
    printf("%d\n",count);
    return 0;
}