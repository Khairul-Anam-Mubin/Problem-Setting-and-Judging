#include<iostream>
#include<cstring>

using namespace std;

int main()
{
    string s;
    int i,j,c=0, n=5;



    for(i=0; i<n; i++){
        cin >> s;
        if(s.length() == 5)
            c++;
    }

    if(c == 5)
        cout << "Mim" << endl;
    else
        cout << "Pocha Dim" << endl;



    return 0;
}