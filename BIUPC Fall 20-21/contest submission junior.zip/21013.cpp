#include<stdio.h>
int main()
{
	int a;
	scanf("%d", &a);
	if(a>= 39 && a<43)
	    printf("Senior division\n");
	else if(a>= 43 && a<47)
	    printf("Junior division\n");
	else
	printf("Out of the division\n");
	
	return 0;
}