#include<bits/stdc++.h>
#define PI  2*acos(0.0)
using namespace std;
int main()
{
    double n,m,a,r;
    int t;
    cin>>t;
    a=0.000000;
    while(t--)
    {
        cin>>n>>m;
        r = (n*m)/(n+m);
   a = (n*m)-(PI*(r*r));
   cout<<fixed;
   cout<<setprecision(6)<<a<<endl;
}
    return 0;
}