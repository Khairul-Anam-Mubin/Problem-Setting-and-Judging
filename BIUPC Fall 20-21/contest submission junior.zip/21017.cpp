#include<iostream>
using namespace std;
int main()
{
    cout<<"Be brave.";
	return 0;
}