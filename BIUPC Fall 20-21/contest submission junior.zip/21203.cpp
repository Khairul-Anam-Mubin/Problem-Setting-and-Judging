#include<iostream>
using namespace std;
int main()
{
    long long int L,R;
    int count_odd=0;

    cin >> L;
    cin >> R;

    for(int i = L; i <= R; i++)
    {
        if(i % 2 == 1)
            count_odd++;
    }
    cout << count_odd<< endl;
    return 0;
}