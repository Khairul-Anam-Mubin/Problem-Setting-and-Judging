#include<iostream>

using namespace std;

int main()
{
    int s, e, i, c=0;

    cin >> s >> e;

    for(i=s; i<=e; i++){
        if(i%2==1)
            c++;
    }

    cout << c << endl;




    return 0;
}