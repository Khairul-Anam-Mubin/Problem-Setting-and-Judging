#include <stdio.h>
 int main ()
{
  int N,T,i;
   scanf("%d",&T);

   for(i=1;i<=T;i++){
     scanf("%d",&N);

    if(N%18==0){
    printf("Yes\n");

}else {
     printf("No\n");
   }

 }
      return 0;
}