#include<stdio.h>
int main()
{
 printf("Be Brave\n");
 return 0;
}