#include <bits/stdc++.h>
using namespace std;
int fun(long long int l, long long int r){

    long long int n = (r - l) / 2;
    if (r % 2 != 0 || l % 2 != 0)
        n++;
    return n;
}

int main()
{
    long long int l,r;
    cin>>l>>r;
    long long int c = fun(l,r);
    cout<<c<<endl;

    return 0;
}