#include<stdio.h>
int main()
{
    printf("Be brave.");
    printf("\n");

    return 0;
}