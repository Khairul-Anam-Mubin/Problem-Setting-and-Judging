#include<bits/stdc++.h>
using namespace std;
int main()
{
    int tc;
    int f=0,in=0,p;
    cin>>tc;
    while(tc--)
    {
        string  arr;
        cin>>arr;
        int a=0,b=0;
        for(int i=0;i<arr.size();i++)
        {
            if(arr[i]=='.')
                {
                    p=i;
                    break;
                }
              a=a*10+arr[i]-'0';
        }
        for(int i=p+1;i<arr.size();i++)
        {
            b=b*10+arr[i]-'0';
        }
       f+=a;
       in+=b;
       if(in>=12)
       {
           f+=in/12;
           in%=12;
       }
       cout<<f<<" Feet, "<<in<<" Inches"<<endl;

    }
   return 0;
}