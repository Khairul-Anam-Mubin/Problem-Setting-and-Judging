#include<stdio.h>
int main()
{
    int t,n;
    double m;
    scanf("%d", &t);
    while(t--){
        scanf("%d", &n);
        (double)n;
        m=n%18;
        if(m==0&&n!=0)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}