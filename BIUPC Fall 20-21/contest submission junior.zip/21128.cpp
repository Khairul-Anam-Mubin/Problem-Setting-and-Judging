#include<iostream>
using namespace std;
int main()
{
	int L,R,cnt=0;

	cin>>L>>R;

        for(int i=L; i<R; i+=2)
        {
            cnt++;
        }

     cout<<cnt<<endl;

	return 0;
}