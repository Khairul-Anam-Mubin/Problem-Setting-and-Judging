#include <stdio.h>
int main()
{
    int x;
    scanf("%d", &x);
    if (x<39)
    {
    printf("Out of division");
    }
    else if (x==39)
    {
    printf("Senior Divison");
    }
    else if (x==40)
    {
    printf("Senior Divison");
    }
    else if (x==41)
    {
    printf("Senior Divison");
    }
    else if (x==42)
    {
    printf("Senior Division");
    }
    else if(x==43)
    {
    printf("Junior divison");
    }
    else if(x==44)
    {
    printf("Junior divison");
    }
    else if(x==45)
    {
    printf("Junior divison");
    }
    else if(x==46)
    {
    printf("Junior divison");
    }
    else
    {
    printf("Out of division");
    }
    return 0;
}