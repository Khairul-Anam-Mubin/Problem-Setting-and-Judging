#include <stdio.h>
int main()
{
    int l,r,count =0;
    scanf("%d%d",&l,&r);
    if(l >= 1 && l<=r && r <= 1000000){
        for(int i=l;i<=r;i++){
            if(i%2 ==1){
              count++;  
            }
        }
        printf("%d\n",count);
    }
   
    return 0;
}