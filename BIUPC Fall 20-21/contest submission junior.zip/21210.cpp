int main()
{


    int T,N,i=1;

    scanf("%d",&T);
    N<=1000;
    for(i=1;i<=T;i++)
        {
            scanf("%d",&N);
            if(N%18==0)
            {
            printf("YES\n");
            }
            else
            {
            printf("NO\n");
            }
        }
        return 0;
}