#include <bits/stdc++.h>
using namespace std;
int main(){
    int intake;
    scanf("%d",&intake);
    if(intake>=39 && intake<=46)
    {
        if(intake>=39 && intake<=42)
            printf("Senior division\n");
        else
            printf("Junior division\n");
    }
    else
        printf("Out of the division\n");

return 0;
}