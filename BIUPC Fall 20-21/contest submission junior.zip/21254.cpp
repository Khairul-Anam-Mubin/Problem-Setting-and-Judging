#include<bits/stdc++.h>
using namespace std;
bool bigMod(string str)
{
    int n = str.length();
    if (n == 1)
        return ((str[0]-'0')%18 == 0);
    if (n == 2)
        return (((str[n-2]-'0')*10 + (str[n-1]-'0'))%18 == 0);
    int last = str[n-1] - '0';
    int second_last = str[n-2] - '0';
    int third_last = str[n-3] - '0';
    return ((third_last*100 + second_last*10 + last) % 18 == 0);
}
int main()
{
    int t;cin>>t;
    while(t--){
        string str;
        cin>>str;
        bigMod(str)?  cout << "YES" : cout << "NO";
        cout<<'\n';
    }
    return 0;
}