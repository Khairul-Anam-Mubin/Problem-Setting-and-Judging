#include<stdio.h>

int Odd_Even(int L, int R){
   int odd = 0;
   for(int i = L ;i <= R ;i++){
      if(i%2 != 0){
         odd++;
      }
   }
   return odd;
}
int main(){
   int L ,R;
   scanf("%d %d",&L,&R);
   int odd = Odd_Even(L, R);
   printf("%d",odd);
   return 0;
}