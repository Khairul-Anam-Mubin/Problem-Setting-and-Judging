#include<iostream>
using namespace std;
int main()
{
    long long int N;
    int T;
    cin>>T;
    for(int i=0; i<T; i++)
    {
        cin>> N;
        if(N%18==0)
        {
            cout<< "YES" << endl;
        }
        else
        {
            cout<<"NO"<<endl;
        }
    }
    return 0;
}