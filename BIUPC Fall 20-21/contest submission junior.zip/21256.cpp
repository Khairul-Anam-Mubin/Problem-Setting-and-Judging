#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    double a, b;
    double r, h ,A, C, Area ;
    int T;
    double PI = 2 * acos(0.0);
    cin>> T;
    for(int i=0;i<T;i++)
    {
        cin>> a;
        cin>> b;
        r=((a*b)/ (a+b));
        h=2*r;
        A=((a+b)/2)*h;
        C= PI*(r*r);
        Area = A-C;
        printf("%.6lf\n", Area);
    }
    return 0;
}