#include<stdio.h>

int main(){
    int n;
    scanf("%d", &n);
    if(n>=39 && n<43){
        printf("Senior division");
    }
    else if(n>=43 && n<=46){
        printf("Junior division");
    }
    else{
        printf("Out of the division");
    }
return 0;
}