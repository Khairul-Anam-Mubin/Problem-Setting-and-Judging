#include <iostream>
using namespace std;
int Odd_Number (int L, int R)
{
   int odd = 0;
   for(int i = L ;i <=R ;i++)
   {
      if(i%2!=0)
    {
         odd++;
      }
   }
   return odd;
}
int main()
{
   int L,R;
   cin>>L>>R;
   int odd = Odd_Number(L, R);
   cout<<odd<<endl;
   return 0;
}