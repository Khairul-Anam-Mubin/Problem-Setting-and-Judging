#include<stdio.h>
void main()
{
    char word[1000];
    int i = 0, yes = 0, no = 0;
    while(i < 5){
    gets(word);
    int length = strlen(word);
    if(length >=5 )
        yes++;
    else
        no++;
        i++;
    }
    if(yes == 5 && no == 0)
        printf("Mim\n");
    else
        printf("Pocha Dim\n");
}