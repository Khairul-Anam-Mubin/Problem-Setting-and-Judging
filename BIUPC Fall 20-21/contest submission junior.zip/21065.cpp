#include <stdio.h>
#include <stdlib.h>

int main()
{
    long long int number;
    int test, i;
    scanf("%d", &test);
    for(i=0; i<test; i++){
        scanf("%lld", &number);
        if(number%18==0){
            printf("YES\n");
        }
        else
            printf("NO\n");
    }
    return 0;
}