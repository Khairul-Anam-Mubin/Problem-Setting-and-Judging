#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

int main()
{
    int t, i, j;
    char s[50];
    int f, x, y,z, num=0, num2=0;


    cin >> t;
    getchar();

    for(j=0; j<t; j++){
        cin >> s;
        y = ((int)s[0]) - 48;
        for(i=1,x=10; i < strlen(s) && s[i] != '.'; i++){
            f = ((int)s[i]) - 48;
            y = y*x + f;
        }
        num += y;
        z = 0;
        if(i+1 < strlen(s))
            z = ((int)s[i+1]) - 48;
        for(i=i+2,x=10; i < strlen(s) && s[i] != '\0'; i++){
            f = ((int)s[i]) - 48;
            z = z*x + f;
        }
        num2 += z;

        if(num2 >= 12){
            num += num2/12;
            num2 = num2%12;
        }

        cout << num << " Feet, " << num2 << " Inches" << endl;


    }




    return 0;
}