#include<stdio.h>
int main()
{
	 int n;
    scanf("%d", &n);
    if(n>39 && n<=43)
        printf("Senior division\n");
    else if(n>43 && n<=46)
        printf("Junior division\n");
    else
        printf("Out of the division\n");
}