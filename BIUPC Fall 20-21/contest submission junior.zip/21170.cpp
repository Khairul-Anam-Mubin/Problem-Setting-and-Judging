#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        char num[1000];
        scanf(" %s",num);
        int i=0;
        int sum = 0;
        while(num[i]){
            sum+=(num[i]-48);
            i++;
        }
        i--;
        if(!(sum%9) && !((num[i]-48)%2)){
            printf("YES\n");
        } else {
            printf("NO\n");
        }
    }
    return 0;
}