#include<bits/stdc++.h>
using namespace std;

int main()
{
    string n[5];

    int i, l=0, cnt=0;

    for(i=0; i<5; i++){
        cin>>n[i];

        l = n[i].length();

        if(l!=5){
            cout<<"Pocha Dim"<<endl;
            break;
        }
        else
            cnt++;
    }
    if(cnt==5)
        cout<<"Mim"<<endl;



    return 0;
}