#include<bits/stdc++.h>

#define ll long long

using namespace std;

ll hasing[1000000];
const int N=1000001;
int main()

{

    ll t, i,j,b,c,d=0,k=0,l,r,x,q;

    hasing[1]=1;
    hasing[2]=2;
    hasing[3]=2;


    for(i=4; i<=1000001; i++)
    {
        k=0;
        d=0;
        for(j=1; j*j<=i; j++)
        {
            if(i%j==0)
            {
                k+=2;
            }

        }

        d=sqrt(i);

        if(d*d==1)
            k--;

        hasing[i]=k;

    }

    cin>>t;

    while(t--)
    {
    k=0;
    d=0;
     cin>>l>>r>>x;

      k=hasing[x];

     ll coun=0;
     for(i=l; i<=r; i++)
     {
      if(hasing[i]==k)
      coun++;

     }

     cout<<coun<<endl;

    }


}