#include <iostream>
#include <cstdio>

using namespace std;
//this code from Bubt Contest S.S.01 * shema, faisal, sohan
int main(void) {
		int t;
		while(scanf("%d", &t)!=EOF) {

			while(t--) {
			int counter = 0;
		unsigned int x;
		cin >> x;
		unsigned int y;
		cin >>y;
		//int counter = 0;
		for(unsigned int i=0; i<y; i++) {
			for(unsigned int j=i; j<y+1; j++) {
					if(((i^j) == x) && (i <= y && j <= y)) {
						counter++;
				}
			}
		}
		cout << counter <<endl;
	}

	}
		return 0;
}