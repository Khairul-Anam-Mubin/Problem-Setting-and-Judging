#include<stdio.h>
int main()
{
	int l,r,count;
	int digits;
	scanf("%d %d",&l, &r);


	if (l==r){
		if(l%2==0)
			count = 0;
		else
			count = 1;
	}
	else if(l%2 == 0 && r%2==0){
		l = l-1;
		digits = r-l;
		count = digits/2 -1;
	}
	else if((l%2 == 0 && r%2!=0) || (l%2 != 0 && r%2==0)){
		l = l-1;
		digits = r-l;
		count = digits/2;
	}
	else{
		l = l-1;
		digits = r-l;
		count = digits/2 +1;
	}
	printf("%d\n",count);
}