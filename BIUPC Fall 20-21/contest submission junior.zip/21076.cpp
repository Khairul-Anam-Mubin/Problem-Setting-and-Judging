#include<bits/stdc++.h>
using namespace std;
int main()
{
    /*
    int t,n,a;
    cin>>t;
    while(t-->0){
        cin>>n>>a;
        int count=0;
        for(int i=0;i<=a;i++){
            for(int j=i+1;j<=a;j++){
                if((i^j)==n){
                    count++;
                }
            }
        }
        cout<<count<<endl;
    }
    */
    int t;
    cin>>t;
    while(t-->0){
        int n,a;
        cin>>n>>a;
        int result = 0;
        set<int> s;

        for (int i=0; i<=a ; i++)
        {
            if (s.find(n^i) != s.end())
                result++;
            s.insert(i);
        }
        cout<<result<<endl;
        }

}