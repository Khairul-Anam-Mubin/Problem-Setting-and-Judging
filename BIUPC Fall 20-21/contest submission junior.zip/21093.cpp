#include<iostream>
using namespace std;

int main()
{
    int t;
    cin>>t;

    for(int i=1;i<=t;i++){
        int n;
        cin>>n;

        if(n%18==0){
            cout<<"YES"<<endl;
        }
            else if (n==1){
                cout<<"YES"<<endl;
            }

        else{
            cout<<"NO"<<endl;
        }
    }
    return 0;

}