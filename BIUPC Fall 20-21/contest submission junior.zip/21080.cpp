#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    scanf("%d",&a);
    if(a>=1 && a<=100){
        
        if(a>=39 && a<=42){
            printf("Senior division");
        }else if(a>=43 && a<=46){
           printf("Junior division");
        }else{
            printf("Out of the division");
        }

    }
    return 0;
}