#include<stdio.h>
int main()
{
    long long int T,N;
    scanf("%lld",&T);
    while(T--)
    {
        scanf("%lld",&N);
        if((N%18)==0)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}