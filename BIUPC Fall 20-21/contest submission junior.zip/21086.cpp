#include <iostream>
#include <cstdio>

using namespace std;
//this code from Bubt Contest S.S.01 * shema, faisal, sohan
int main(void) {
		int t;
		while(scanf("%d", &t)!=EOF) {
				if(t < 39 || t > 46) {
					cout << "Out of the division" <<endl;
				}else{
					if(t >= 39 && t <=43) {
						cout << "Senior division" <<endl;
					}
					if(t >= 43 && t <=46) {
							cout << "Junior division" <<endl;
					}
				}
		}
		return 0;
}