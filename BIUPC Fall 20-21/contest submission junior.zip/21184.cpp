#include<stdio.h>
int main()
{
	int A;
	scanf("%d", &A);
	if(A >= 39 && A <= 42) printf("Senior division\n");
	else if(A >= 42 && A <= 46 ) printf("Junior division\n");
	else printf("Out of the division\n");
    return 0;
}