#include<iostream>
using namespace std;

int main()
{
	int n;
	
	cin>>n;

	if(n==39 || n==40 || n==41 || n==42)
    {
        cout<<"Senior division"<<endl;
    }
    else if (n==43 || n==44 || n==45 || n==46)
    {
        cout<<"Junior division"<<endl;
    }
    else cout<<"Out of the division"<<endl;

	return 0;
}