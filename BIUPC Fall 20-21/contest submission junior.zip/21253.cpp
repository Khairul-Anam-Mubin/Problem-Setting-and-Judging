#include<stdio.h>
int main()
{
	int t,r,temp,sum=0;
	unsigned long long number;
	scanf("%d",&t);

	for(int i = 0 ; i < t ; i++) {
        scanf("%llu",&number);
        if(number % 2 == 0) {
              temp = number;
              while(temp!=0)
              {
                r=temp%10;
                sum=sum+r;
                temp=temp/10;
              }
              if(sum % 9 == 0) {
                printf("YES\n");
              } else {
                  printf("NO\n");
              }
        } else {
            printf("NO\n");
        }
	}

}