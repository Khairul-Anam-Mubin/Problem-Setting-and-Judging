#include<stdio.h>
int main()
{
int i,L,R,c=0;
scanf("%d%d",&L,&R);
for(i=L;i<=R;i++)
{
    if(i%2==1)
    c++;

}
printf("%d",c);
}