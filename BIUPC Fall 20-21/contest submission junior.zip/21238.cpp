#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>

using namespace std;
//this code from Bubt Contest S.S.01 * shema, faisal, sohan
int main(void) {
		
		
		
			int total = 0;
			string a, b, c, d, e;
			cin >>a>>b>>c>>d>>e;	
			total+=a.size()+b.size()+c.size()+d.size()+e.size();
			
			if(total != 25) {
				cout << "Pocha Dim" <<endl;
			}
			
		
				
		return 0;
}