#include<stdio.h>
int main()
{
	printf("404 not found !!\n");
}