#include<stdio.h>
int main()
{
    printf("Im a programmer!");
    return 0;
}