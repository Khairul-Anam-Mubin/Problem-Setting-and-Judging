#include<stdio.h>
main(){
    int n;
    scanf("%d", &n);
    if(n>38 && n<=42)
        printf("Senior division\n");
    else if(n>42 && n<=46)
        printf("Junior division\n");
    else
        printf("Out of the division\n");
}