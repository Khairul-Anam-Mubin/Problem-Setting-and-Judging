#include<stdio.h>
int main()
{
	prinf("404 not found !!\n");
}