#include<stdio.h>
int main()
{
	printf("Be brave.\n");
	return 0;
}