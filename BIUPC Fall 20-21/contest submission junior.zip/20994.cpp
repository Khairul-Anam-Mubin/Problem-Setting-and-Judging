#include<iostream>
using namespace std;
int main(){
int A;
cin>>A;
if(A<=42&&A>=39){
cout<<"Senior division"<<endl;
}
else if(A<=46&&A>=43){
  cout<<"Junior division"<<endl;
}
else{
 cout<<"Out of the division"<<endl;
}
return 0;
}