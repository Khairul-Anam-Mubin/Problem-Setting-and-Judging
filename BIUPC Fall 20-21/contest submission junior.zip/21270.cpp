#include<stdio.h>
int main()
{
  int T;
  scanf("%d", &T);
  for(int i=0;i<T;i++){
    double a,b,r,trap,circle,PI=2*acos(0.0);
    scanf("%lf%lf",&a,&b);
    r=(a*b)/(a+b);
    trap=((a+b)/2)*(r*2);
    circle=PI*r*r;
    printf("%lf\n",trap-circle);
  }
}