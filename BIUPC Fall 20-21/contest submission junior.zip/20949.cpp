#include<stdio.h>
int main()
{
	ptintf("Be brave.");
}