#include<iostream>

using namespace std;


int main ()
{


        int l,r,p;
        cin >>l>>r;
           p=0;
        for (int i=l;i<=r;i++){
            if (i%2!=0){
                p++;
            }
        }

        cout<<p<<endl;







    return 0;
}