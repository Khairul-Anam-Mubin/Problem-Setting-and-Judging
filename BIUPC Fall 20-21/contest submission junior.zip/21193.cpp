#include <stdio.h>
int main()
{
 int T, i, result;
 double N, frac;
 scanf("%d", &T);
 
 for(i = 1; i <= T; i++) {
  
  scanf("%lf", &N);
        frac = N - (int)N;
    
  if((int)(N)%  18 == 0 && frac == 0.0) {

  printf("YES\n");
 
  }
  else {
   printf("NO\n");
  }

 }
   return 0;
}