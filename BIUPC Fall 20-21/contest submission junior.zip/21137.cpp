#include <stdio.h>
int main()
{
    long long l, r, count = 0;

    scanf("%llu %llu", &l, &r);

    for (; l <= r; l++)
    {
        if (l % 2 == 1)
        {
            count++;
        }
    }
    printf("%llu\n", count);

    return 0;
}