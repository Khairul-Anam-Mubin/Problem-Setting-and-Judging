#include <iostream>
using namespace std;
int main() {
    int t;
    cin >> t;
    while(t--){
        long long int n,x,c=0;
        cin >> n >> x;
        for (long long int  i = 0,j=1; i<=x && j<=x; i=i+2,j=j+2) {

                c++;
        }
        cout << c << endl;
    }

    return 0;
}