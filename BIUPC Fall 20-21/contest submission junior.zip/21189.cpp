#include<stdio.h>
#include<string.h>
int main(){
    int pochadim = 0, i;
    for(i=0; i<5; i++){
        char word[1000];
        scanf("%s",word);
        if(strlen(word)!=5){
            pochadim = 1;
        }
    }
    if(pochadim){
        printf("Pocha Dim\n");
    } else {
        printf("Mim\n");
    }
}