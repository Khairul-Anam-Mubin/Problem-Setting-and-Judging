#include <stdio.h>
int main()
{
    int L,R,i,odd=0;
    scanf("%d %d",&L,&R);
    for(i=L; i<=R; i++)
    {
        if(i%2!=0)
            odd++;
    }
    printf("%d\n",odd);
    return 0;
}