#include<bits/stdc++.h>
using namespace std;
int main()
{
    int N;
        cin>>N;
        if(43<=N && 46>=N){
            cout<<"Junior division"<<endl;
        }
        else if(39<=N && 42>=N){
            cout<<"Senior division"<<endl;
        }
        else
            cout<<"Out of the division"<<endl;
    return 0;
}