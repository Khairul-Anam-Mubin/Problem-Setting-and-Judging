#include <stdio.h>

 int main()
  {

     int T,N,i;
     scanf("%d",&T);
     for(i=1; i<=T; i++)
     {

    scanf("%d",&N);
    if(N % 18 == 0)
    {
    printf("YES\n", N);
    }
    else
    {


        printf("NO\n", N);
    }


     }

     return(0);
  }