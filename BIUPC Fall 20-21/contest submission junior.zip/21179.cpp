#include<stdio.h>
int main()
{
	 int i,t,n;
    scanf("%d", &t);
    for(i=1; i<=t; i++){
        scanf("%d", &n);
        if(n%18==0)
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}