#include<bits/stdc++.h>
using namespace std;
int main()
{
    /*
    int t;
    cin>>t;
    while(t-->0){
        int n,a;
        cin>>n>>a;
        int result = 0;
        set<int> s;

        for (int i=0; i<=a ; i++)
        {
            if (s.find(n^i) != s.end())
                result++;
            s.insert(i);
        }
        cout<<result<<endl;
        }
*/

    int t;
    cin>>t;
    while(t-->0){
        int n,a;
    cin>>n>>a;
    int result = 0;
    map<int, int> m;

    for (int i=0; i<=a ; i++)
    {
        int curr_xor =  n^i;
        if (m.find(curr_xor) != m.end())
            result += m[curr_xor];
        m[i]++;
    }

    cout<<result<<endl;
    }
    return 0;
}