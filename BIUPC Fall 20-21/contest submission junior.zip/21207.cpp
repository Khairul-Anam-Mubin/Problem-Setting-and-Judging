#include<stdio.h>
int main()
{
	int t;
	unsigned long long number;
	scanf("%d",&t);

	for(int i = 0 ; i < t ; i++) {
        scanf("%llu",&number);
        if(number % 18 == 0 ) {
            printf("YES\n");
        } else {
            printf("NO\n");
        }
	}

}