#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
    int len, i, t;
    char n[1000 + 5];
    long long sum, b = 18;
    scanf("%d", &t);
    while(t--) {
      scanf("%s", n);
      len=strlen(n);
      sum=0;
      if(b<0)
         b= -b;
      for(i=0; i<len; i++) {
            if(n[i]=='-') continue;
            sum=sum+(n[i]-'0');
            if(sum>=b)
                sum=sum%b;
            if(sum<b)
                sum=sum*10;
        }
        if(sum==0)     printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}