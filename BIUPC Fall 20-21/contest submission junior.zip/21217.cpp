#include<stdio.h>
int main()
{
	char s[1000],len=0,i,count=0;
    for(i=0; i<5; i++){
        scanf("%s", s);
        len = strlen(s);
        if(len == 5)
            count++;
            len = 0;
    }
   if(count==5)
    printf("Mim\n");
   else
    printf("Pocha Dim\n");
    return 0;
}