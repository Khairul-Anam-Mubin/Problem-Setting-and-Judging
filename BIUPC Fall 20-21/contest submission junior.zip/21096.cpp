#include<bits/stdc++.h>
using namespace std;
int main()
{
    int T,n;
    cin>>T;
    while(T != 0){
        T--;
        cin>>n;
        if(n%18==0){
            cout<<"YES"<<endl;
        }
        else
        cout<<"NO"<<endl;
    }
    return 0;
}