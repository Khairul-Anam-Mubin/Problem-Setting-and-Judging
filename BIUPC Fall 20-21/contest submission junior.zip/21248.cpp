#include <stdio.h>
#include <math.h>
int main()
{
    unsigned long long T, N, i;
    scanf("%llu", &T);
    for (i = 1; i <= T; i++)
    {

        scanf("%llu", &N);
        if (N >= pow(10, 999))
        {

            break;
        }
        if (N % 18 == 0)
        {
            printf("YES\n");
        }

        else
        {

            printf("NO\n");
        }
    }

    return 0;
}