#include <bits/stdc++.h>
using namespace std;

int main()
{
    int l,r, rem, flag=0;
    cin>>l>>r;
    for(int i=l; i<=r && i<=1000000; i++)
    {
        rem = i % 2;
        if (rem == 1)
        {
            flag++;
        }

    }
    cout << flag<< endl;

    return 0;

}