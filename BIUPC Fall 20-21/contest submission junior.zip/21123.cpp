#include<bits/stdc++.h>
using namespace std;
int main()
{
    int N,a;
    scanf("%d",&N);
    for(int i=0; i<N; i++)
    {
        scanf("%d",&a);
        if(a<=1000)
        {


            if(a%18==0)
            {
                printf("YES\n");
            }
            else
            {
                printf("NO\n");
            }
        }
    }
    return 0;
}