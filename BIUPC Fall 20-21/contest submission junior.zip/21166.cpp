#include<bits/stdc++.h>
using namespace std;

int main()
{
    int T,a,b,n,N;
    cin >> T;

        for (int n=1;n<=100;n++)
        {
            cin>> N;

            if(N%18==0)
            {
                cout << "YES"<<endl;
            }

            else

            {
                cout << "NO"<<endl;
            }

        }
    return 0;
}