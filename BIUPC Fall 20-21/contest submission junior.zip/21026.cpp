#include<bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin>>n;
    if(n>=43&&n<=46)
    cout<<"Junior division";
    else if(n>=39&&n<43)
    cout<<"Senior division";
    else
    cout<<"Out of the division";
   cout<<endl;
  return 0;
}