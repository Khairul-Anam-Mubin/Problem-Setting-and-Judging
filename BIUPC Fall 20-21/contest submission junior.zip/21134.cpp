#include<stdio.h>
int main()
{
	char st1[1002],st2[1002],st3[1002],st4[1002],st5[1002];
	gets(st1);
	gets(st2);
	gets(st3);
	gets(st4);
	gets(st5);
	int a,b,c,d,e;
	a=strlen(st1);
	b=strlen(st2);
	c=strlen(st3);
	d=strlen(st4);
	e=strlen(st5);
	if(a==5&&b==5&&c==5&&d==5&&e==5){
        printf("Mim\n");
	}
	else{
        printf("Pocha Dim\n");
	}
	return 0;
}