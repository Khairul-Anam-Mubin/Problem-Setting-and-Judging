#include <stdio.h>

int main(void) {
  int A;
  scanf("%d", &A);


	if(A>=39 && A <=43) {
        printf("Senior division\n");
	} else if (A >= 44 && A<=46) {
	     printf("Junior division\n");
	} else{
	     printf("Out of the division\n");
	}

  return 0;
}