#include <stdio.h>
#include <string.h>
void main()
{
    char string[1005];
    int count, sum = 0;
    int t;


    scanf("%s", string);
    for (count = 0; string[count] != '\0'; count++)
    {
        if ((string[count] >= '0') && (string[count] <= '9'))
        {
            sum += (string[count] - '0');
        }
    }
    //sum/9==1
    if(sum%9 == 0){
        if(strlen(string) == 1)
            printf("NO\n");
        else
            printf("YES\n");
    }
    else
        printf("NO\n");
}