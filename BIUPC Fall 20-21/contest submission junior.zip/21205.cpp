#include<bits/stdc++.h>
using namespace std;
int main()
{
    int T,i=1,n;
    cin>>T;
    while(i <= T){
        i++;
        cin>>n;
        if(n<=1000){
            if(n%18==0)
                cout<<"YES"<<endl;
            else
                cout<<"NO"<<endl;
        }
    }

    return 0;
}