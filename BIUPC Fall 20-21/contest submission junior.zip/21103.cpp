#include<iostream>
using namespace std;
int main()
{
	int L,R,cnt=0;

	scanf( "%d %d",&L,&R);

//	if(L%2==0)
//    {
        for(int i=L; i<R; i+=2)
        {
            cnt++;
        }
//    }
        //


     printf("%d\n",cnt);

	return 0;