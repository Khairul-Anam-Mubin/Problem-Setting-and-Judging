#include<stdio.h>
int main()
{
    long l,r;
    int i,match=0;
    scanf("%ld %ld",&l,&r);
    for(i=l;i<=r;i++)
        if(i%2!=0)match++;

    printf("%d\n",match);
    return 0;
}