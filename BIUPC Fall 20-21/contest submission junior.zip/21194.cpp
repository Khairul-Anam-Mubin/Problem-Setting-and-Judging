#include <iostream>

using namespace std;


int main()
{
    int a;
    cout << " Enter your Intake :";
    cin>>a;
    if(39<=a && a<=46){
        if(39<=a && a<=42)
        cout<<"Intake " << a <<" Senior division";
        else
        cout << "Intake " << a <<" Junior division";
    }
    else
        cout<< "Intake " << a <<" Out of the division";
        return 0;

}