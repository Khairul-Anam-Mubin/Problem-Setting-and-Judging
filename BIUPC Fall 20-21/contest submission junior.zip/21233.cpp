#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define yes "YES"
#define no "NO"
#define pb push_back
#define si size()
#define in " "
#define mone "-1"
#define zero "0"
#define one "1"
#define PI acos(-1)
ll a[10000000];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    for(ll i=1; i<=1000000; i++)
    {
        for(ll j=i; j<=1000000; j+=i)
        {
            a[j]=a[j]+1;
        }
    }
    ll t;
    cin >> t;
    while (t--)
    {
        ll l,r,x,cont=0;
        cin>>l>>r>>x;
        for(ll i=l;i<=r;i++)
        {
            if(a[i]==x)
                cont++;
        }
        cout<<cont<<endl;
    }
    return 0;
}