#include<stdio.h>
int main(){
  printf("I want to be a good programmer.");
}