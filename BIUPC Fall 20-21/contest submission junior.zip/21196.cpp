#include<stdio.h>
#include<string.h>
int main()
{
   char a[1000];
   int len,test,sum;
   scanf("%d",&test);
   while(test--)
   {
       sum=0;
       scanf("%s",a);
   len=strlen(a);
   for(int i=0;i<len;i++)
    sum+=(a[i]-48);

   if(((a[len-1])%2==0)&&sum%9==0)
    printf("YES\n");
   else printf("NO\n");
   }
   return 0;
}