#include<iostream>
#include<string.h>

#define ll long long

using namespace std;

int main()

{
  ll n,i,b=0,c=0,t,sum=0;
  char a[10000];

  cin>>t;

  while(t--)
  {
  n=0;
   cin>>a;
 sum=0;
   n=strlen(a);

    b=a[n-1]-48;

    if(b%2==1)
    cout<<"NO\n";

    else
    {
    for(i=0; i<n; i++)
    sum+=a[i]-48;

    if(sum%9==0)
    cout<<"YES\n";

    else
    cout<<"NO\n";

    }

   }

}