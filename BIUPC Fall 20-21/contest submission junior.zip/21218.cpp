#include <stdio.h>

int main()
{
    int T, i, n;

    scanf("%d", &T);

    for(i = 1; i <= T; i++)
    {
        scanf("%d", &n);

        if(n%18 == 0)
        {
            printf("YES\n");
        }
        else
        {
            printf("NO\n");
        }
    }

    return 0;
}