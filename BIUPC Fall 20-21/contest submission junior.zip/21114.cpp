#include<stdio.h>
int main()
{
    char str[50];
    int i,n=0,l;

    for(i=0;i<5;i++)
    {
        gets(str);
        l=strlen(str);
        if(l==5)
        {
            n=n+1;
        }

    }
    if(n==5)
    {
        printf("Mim\n");
    }
    else
    {
        printf("Pocha Dim\n");
    }
}