#include<stdio.h>
int main()
{
	int t,n;
    scanf("%d", &t);
    while(t--){
        scanf("%d", &n);
        if(n%18==0)
            printf("YES\n");
        else
            printf("NO\n");
    }
}