#include<bits/stdc++.h>
using namespace std;

int main()
{
    int t, i;

    cin>>t;
    int n;

    for(i=0; i<t; i++){
        cin>>n;

        if(n%18==0)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }



    return 0;
}