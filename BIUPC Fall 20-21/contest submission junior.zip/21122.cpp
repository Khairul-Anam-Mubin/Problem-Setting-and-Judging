#include <iostream>
#include <cstdio>

using namespace std;
//this code from Bubt Contest S.S.01 * shema, faisal, sohan
int main(void) {
		unsigned int a,b;
		while(scanf("%d%d", &a, &b)!=EOF) {
			unsigned int counter=0;
			if(a%2==0) {
					for(unsigned int i=a; i<=b; i+=1){
						counter++;
					}
					counter /=2;
			}else{
					for(unsigned int i=a; i<=b; i+=2){
						counter++;
					}
			}
			cout << counter <<endl;

		}

		return 0;
}