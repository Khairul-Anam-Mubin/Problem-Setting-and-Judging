#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>

using namespace std;
//this code from Bubt Contest S.S.01 * shema, faisal, sohan
int main(void) {
		
		//while(scanf("%c", &x) != EOF) {
			string a;
			int c=4;
			int total=0;
			while(c-- >=0) {
			cin>>a;
			total +=a.size();
			}
			if(total != 25) {
				cout << "Pocha Dim"<<endl;
			}
			//}
		//count << counter <<endl;
				
		return 0;
}