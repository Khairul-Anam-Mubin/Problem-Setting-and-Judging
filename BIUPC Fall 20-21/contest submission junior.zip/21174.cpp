#include <iostream>

using namespace std;


int main()
{
    int a;
    cout << " Enter your Intake : " ;
    cin>>a;

    while  (1 <= a <= 100) {
    if(39<=a && a<=46){
        if(39<=a && a<=42)
        cout<<"Senior division";
        else
        cout<<"Junior division";
    }

    else
        cout<<"Out of the division";
    }

        return 0;

}