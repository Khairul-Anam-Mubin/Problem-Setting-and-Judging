#include <stdio.h>

int main()
{
    char str[50],count=0;
    int i;

   for(i=0; i<5; i++)
    {
        gets(str);
        int len = strlen(str);
        if(len>0 || len<1000){
            return 0;
        }
        
        if(len == 5){
            count = count+1;
        }
    }
    if(count == 5){
        printf("Mim\n");
    }else{
        printf("Pocha Dim\n");
    }

    return 0;
}