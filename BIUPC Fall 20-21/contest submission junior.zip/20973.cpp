#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;cin>>n;
    if(n<=39 && n>=42){
        cout<<"Senior division"<<'\n';
    }
    else if(n<=43 && n>=46){
        cout<<"Junior division"<<'\n';
    }
    else
        cout<<"Out of the division"<<'\n';
    return 0;
}