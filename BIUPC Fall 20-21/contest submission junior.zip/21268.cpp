#include<bits/stdc++.h>

#include<string.h>

#define ll long long

using namespace std;

int main()

{
  int t,b=0,c1=0,c2=0,i;

  cin>>t;


  while(t--)
  {
   string a,s,si;

   cin>>a;

   b=0;
   int c=0;
 int e=0;
   for(i=0; i<a.size(); i++)
    {
     if(a[i]=='.')
     {
      e=i+1;
     break;

     }

     si+=a[i];

    }
int j=0;
    for(j=e; j<a.size(); j++)
     s+=a[j];


     b=stoi(si);

     c=stoi(s);


    c1+=b;
    c2+=c;
    if(c2>=12)
    {
     c1+=c2/12;

     c2%=12;

    }

    cout<<c1<<" "<<"Feet, "<<c2<<" "<<"Inches"<<endl;






  }


}