#include <bits/stdc++.h>

using namespace std;

int main()
{
    int i=5,c=0;
    while(i--){
        string s;
        cin >> s;
        if(s.size() !=5){
            c=1;
        }

    }
    if(c==0){
        cout<<"Mim"<<endl;
    } else{
        cout<<"Pocha Dim"<<endl;

    }
    return 0;
}