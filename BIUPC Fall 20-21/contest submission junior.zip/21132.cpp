#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
    int l1,l2,l3,l4,l5;
    char s1[1005],s2[1005],s3[1005],s4[1005],s5[1005];
    scanf("%s",s1);
    scanf("%s",s2);
    scanf("%s",s3);
    scanf("%s",s4);
    scanf("%s",s5);
    l1=strlen(s1);
     l2=strlen(s2);
      l3=strlen(s3);
       l4=strlen(s4);
        l5=strlen(s5);
    if(l1==5 && l2==5 && l3==5 && l4==5 && l5==5){
        printf("Mim\n");
    }
    else{
        printf("Pocha Dim\n");
    }
    return 0;
}