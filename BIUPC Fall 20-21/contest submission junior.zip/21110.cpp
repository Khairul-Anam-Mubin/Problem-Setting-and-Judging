#include<bits/stdc++.h>
using namespace std;

int main()
{
    int count=0;
    string name;
    for(int i=1; i<=5; i++)

    {
        cin>>name;
        if(name.size()==5)
        {
            count++;
        }
    }
    if(count==5)
    {
        cout << "Mim"<<endl;
    }
    else
    {
        cout << "Pocha Dim"<<endl;
    }

    return 0;
}