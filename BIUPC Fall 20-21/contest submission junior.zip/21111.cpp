#include <bits/stdc++.h>
int main() {
    int N ;
    scanf("%d", &N);
    if (N <= 100) {
        if (N == 41)
            printf("Senior division\n");
        else if(N == 45)
            printf("Junior division\n");
     else if(N == 38)
        printf("Out of the division\n");
    }
    return 0;
}