#include<iostream>
#include<string>
using namespace std;
int main()
{
    int t;
    scanf("%d",&t);
    int sumf=0,sumi=0;
    while(t--)
    {
        string s,s1,s2;
        cin>>s;
        s1=s.substr(0,s.find('.'));
        s2=s.substr(s.find('.')+1);

        int feet=0,inches=0;
        feet=stoi(s1);
        inches=stoi(s2);

        sumf+=feet;
        sumi+=inches;
        if(sumi>=12)
        {
            sumf+=sumi/12;
            sumi=sumi%12;
        }
        printf("%d Feet, %d Inches\n",sumf,sumi);
    }
    return 0;
}