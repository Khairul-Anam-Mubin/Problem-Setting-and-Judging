#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define yes "YES"
#define no "NO"
#define pb push_back
#define si size()
#define in " "
#define mone "-1"
#define zero "0"
#define one "1"
#define PI acos(-1)
//ll lcm(ll a,ll b)
//{
//    return (a*b/(__gcd(a,b)));
//}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    ll t;
    cin >> t;
    while (t--)
    {
        ll n,x,c=0;
        string s;
        cin>>s;
//        if(ss[0]=='0'&&strlen(ss)==1)
//            break;
        for(ll i=0;i<s.size();i++)
            c=(c*10+s[i]-'0')%18;
        if(c==0)
            cout<<yes<<endl;
        else
            cout<<no<<endl;
    }
    return 0;
}