#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){

    int l,h,res;
    scanf("%d %d", &l,&h);
    res = h-l;
    if(res%2==0)
        res = res/2;
    else
        res = (res/2)+1;
    printf("%d\n",res);
    return 0;
}