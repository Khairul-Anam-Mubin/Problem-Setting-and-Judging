#include <stdio.h>

int main(void) {
  int L, R;
  int odd=0;
  scanf("%d%d",&L,&R);
  for(int i=L;i<=R;i++)
  {
    if(i%2!=0)
    {
      odd++;
    }
  }
  printf("%d", odd);

  return 0;
}