#include<stdio.h>
int main()
{

int A;
scanf("%d",&A);

  if(A<=38)
  {
  printf("Out of the division\n");
  }
  else if(A>=47)
  {
  printf("Out of the division\n");
  }
  else if(A<=42)
  {
  printf("Senior division\n");
  }
  else if (A<=46)
  {
  printf("Junior division\n");
  }

    return 0;
}