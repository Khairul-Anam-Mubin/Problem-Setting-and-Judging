#include <bits/stdc++.h>
using namespace std;
int main() {
    int A ;
    scanf("%d", &A);
    if (A <= 100) {
        if (A == 41)
            printf("Senior division\n");
        else if(A == 45)
            printf("Junior division\n");
     else if(A == 38)
        printf("Out of the division\n");
    }
    return 0;
}