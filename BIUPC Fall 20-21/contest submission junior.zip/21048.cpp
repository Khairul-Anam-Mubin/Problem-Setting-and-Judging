#include<stdio.h>
int main()
{
    int n;
    scanf("%d",&n);
    if(n>38 && n<43)
    {
        printf("Senior division\n");
    }
    else if(n>42 && n<47)
    {
        printf("Junior division\n");
    }
    else
    {
        printf("Out of the division\n");
    }


}