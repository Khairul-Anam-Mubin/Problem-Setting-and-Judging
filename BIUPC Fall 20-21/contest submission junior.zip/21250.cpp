#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,f,ff=0,in=0;
    scanf("%d",&n);
    for(int i=0; i<n; i++)
    {
        float a;
        scanf("%f",&a);
        f=a;
        ff=ff+a;
        float tmp=a-f;

        in=in+(tmp*10);
        if(in==12)
        {
            ff=ff+1;
            in=0;
        }

        printf("%d Feet, %d Inches\n",ff,in);
    }
    return 0;
}