#include<stdio.h>
int main()
{
	int i,x,y,count=0;
    scanf("%d %d", &x, &y);
    for(i=x; i<=y; i++){
        if(i%2 != 0)
            count++;
    }
    printf("%d\n", count);
    return 0;
}