#include<stdio.h>
int main()
{
    int n,x,y,feet=0,in=0;
    float a,fy;
    char c;
    scanf("%d",&n);
   while(n--)
   {
        scanf("%f",&a);
        x=a;
        fy=a-x;
        fy=fy*100;
        if(fy>=20)
            y=fy/10.0;

        else y=fy;

    feet+=x;
    in+=y;
    if(in>=12)
    {
        while(in>=12)
        {
            in-=12;
            feet++;
        }
    }
    printf("%d Feet, %d Inches\n",feet,in);

   }
return 0;
}