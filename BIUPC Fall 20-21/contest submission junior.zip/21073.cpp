#include<iostream>

using namespace std;

int main()
{
    int t;

    cin >> t;

    if(39 <= t && 42 >= t)
        cout << "Senior division" << endl;

    else if(43 <= t && 46 >= t)
        cout << "Junior division" << endl;

    else
        cout << "Out of the division" << endl;



    return 0;
}