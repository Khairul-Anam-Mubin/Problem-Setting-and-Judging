#include<stdio.h>

int main(){
    int N, result;
    scanf("%d", &N);

    result = 18 % N;

    if(result==0){
        printf("YES\n");
    }

    else{
        printf("NO\n");
    }
return 0;
}