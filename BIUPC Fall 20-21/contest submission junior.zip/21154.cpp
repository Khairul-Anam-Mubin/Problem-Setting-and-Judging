#include<stdio.h>
int main()
{
    int L, R, i, count=0;

    scanf("%d%d",&L,&R);
    for(i=L; i<=R; i++)
    {
        if(i%2!=0)
            count++;
    }
    printf("%d",count);
    printf("\n");

    return 0;
}