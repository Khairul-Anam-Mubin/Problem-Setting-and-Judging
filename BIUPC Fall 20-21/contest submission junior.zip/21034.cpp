#include <stdio.h>

int main(void) {
  int A;
  scanf("%d", &A);

  if(A>=39 && A<43){
    printf("Senior division");
  }

  if(A>=43 && A<=46){
    printf("Junior division");
  }

  if(A>46 || A<39){
    printf("Out of the division");
  }

  return 0;
}