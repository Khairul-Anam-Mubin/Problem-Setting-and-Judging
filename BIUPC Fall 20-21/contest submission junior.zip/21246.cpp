#include<stdio.h>
#include<math.h>
int main(){
    int n;
    scanf("%d",&n);
    while(n--){
       int a, b;
       scanf("%d %d",&a,&b);
       double r =  (double)(a*b)/(double)(a+b);
       double tA = a*b;
       double cA = 2*acos(0.0)*r*r;
       printf("%.6lf\n",tA-cA);
    }
    return 0;
}