#include<iostream>
using namespace std;

int main()
{
	int t,n,flag=0,flg=0;

	cin>>t;

	for(int i=0; i<t; i++)
    {
        cin>>n;

        if(n==1)
        {
            cout<<"YES"<<endl;
            flag++;
        }

        else if(n%18==0 && flag==0)
        {
            cout<<"YES"<<endl;
            flg++;
        }

        else if(flag==0 && flg==0)
        {
            cout<<"No"<<endl;
        }

        flag==0;flg=0;
    }
	return 0;
}