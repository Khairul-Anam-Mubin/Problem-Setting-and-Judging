#include<stdio.h>
int main()
{
    int n, i, array[100];
    scanf("%d", &n);
    for(i=0; i<n; i++)
    {
        scanf("%d",&array[i]);
    }
    for(i=0; i<n; i++)
    {
        if(array[i]%18==0)
        {
            printf("YES\n");
        }
        else
        {
            printf("NO\n");
        }
    }

    return 0;
    
}