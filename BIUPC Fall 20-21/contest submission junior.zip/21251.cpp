#include <stdio.h>
#include <string.h>
int main()
{
  char strings[5][100];
  int yes=0;

  scanf("%s %s %s %s %s", strings[0], strings[1], strings[2], strings[3], strings[4]);
  
  for(int j=0; j<5; j++) {
    if(strlen(strings[j]) == 5)
      yes++;
  }

  if(yes!=5) {
    printf("Pocha Dim");
  }else {
    printf("Mim");
  }
  return 0;
}