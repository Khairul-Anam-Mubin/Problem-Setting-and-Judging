#include <iostream>
#include <cstdio>

using namespace std;
//this code from Bubt Contest S.S.01 * shema, faisal, sohan
int main(void) {
	
	
		cout << "Be brave." <<endl;
	
		return 0;
}