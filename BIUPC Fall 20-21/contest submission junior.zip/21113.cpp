#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    scanf("%d",&a);
    if(a>=1 && a<=100){
        
        if(a>=43 && a<=46){
           printf("Junior division");
           return 0;
        }
        if(a>=39){
            printf("Senior division");
           return 0;
        }
        
        printf("Out of the division");
        

    }
    return 0;
}