#include <iostream>
using namespace std;
int main() {
    int t;
    cin >>t;
    if(t>=43 && t<=46){

        cout << "Junior division" << endl;
    }else if(t>=39 &&    t<=42){
        cout << "Senior division" << endl;
    }else{
        cout << "Out of the division"<<endl;
    }
    return 0;
}