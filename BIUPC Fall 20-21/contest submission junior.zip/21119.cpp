#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    char s[5][1000];
    bool flag=true;
    for(int i=0;i<5;i++)
    {
        scanf("%s",s[i]);
        if(strlen(s[i])!=5)flag=false;

    }
    if(flag==true)printf("Mim\n");
    else printf("Pocha Dim\n");
    return 0;
}