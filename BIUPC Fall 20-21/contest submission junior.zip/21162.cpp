#include<bits/stdc++.h>
using namespace std;
int main()
{
    string  a, b,c,d,e;
    cin >> a;
    cin >> b ;
    cin >> c ;
    cin >> d ;
    cin >> e ;
    if(a.size()==5 && b.size()==5 && c.size()==5 && d.size()==5 && e.size()==5)
    {
        cout <<"Mim\n";
    }
    else{
        cout <<"pocha dim\n";
    }
}