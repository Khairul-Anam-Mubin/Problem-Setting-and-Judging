#include<stdio.h>
int main()
{
	int intake;
	scanf("%d",&intake);

	if(intake>=39 && intake <=43) {
        printf("Senior division\n");
	} else if (intake >= 44 && intake<=46) {
	     printf("Junior division\n");
	} else{
	     printf("Out of the division\n");
	}

}