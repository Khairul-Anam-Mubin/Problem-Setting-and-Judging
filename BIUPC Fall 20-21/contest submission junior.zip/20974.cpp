#include<iostream>

#define ll long long

using namespace std;

int main()

{
	cout<<"Be brave.\n";


}