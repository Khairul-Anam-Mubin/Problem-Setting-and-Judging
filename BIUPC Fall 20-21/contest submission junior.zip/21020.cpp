#include<bits/stdc++.h>

#define ll long long

using namespace std;

int main()

{

  int l,r;

  cin>>l>>r;

  int i,j,k=0;

  for(i=l; i<=r; i++)
  {
   if(i%2==1)
   k++;
  }


   cout<<k<<endl;
}