#include<stdio.h>

int main()
{
    int input;
    scanf("%d",&input);
    if ( 18 % input ==0)
    {
     printf("YES");
    }
    else
    {
        printf("NO");
    }

        return 0;

}