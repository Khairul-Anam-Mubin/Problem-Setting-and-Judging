#include<stdio.h>
int main()
{
int i,L,R,c=0;
scanf("%d%d",&L,&R);
if(1<=L && L<=R && R<=10^6){
for(i=L;i<=R;i++)
{
    if(i%2==1)
    c++;

}
printf("%d",c);
}
}