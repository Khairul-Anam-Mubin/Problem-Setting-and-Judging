#include <stdio.h>

int main()
{
    int a;
    scanf("%d",&a);
    if(a>=1 && a<=100){
        
        if(a>=43 && a<=46){
           printf("Junior division\n");
           return 0;
        }
        if(a>=39 && a<=42){
            printf("Senior division\n");
           return 0;
        }
        
        printf("Out of the division\n");
        

    }
    return 0;
}