#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main ()
{
	int test, i, iNum;
	char num[101];
	scanf("%d", &test);
	for(i=1; i<=test; i++){
		scanf("%s", num);
		iNum= atoi(num);
		if(iNum % 18 ==0)
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
}