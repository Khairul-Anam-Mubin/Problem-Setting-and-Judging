#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s1,s2,s3,s4,s5;
    cin>>s1;
    cin>>s2;
    cin>>s3;
    cin>>s4;
    cin>>s5;

    if(s1.size()==5 && s2.size()==5 && s3.size()==5 && s4.size()==5 && s5.size()==5){
        cout<<"Mim"<<'\n';
    }
    else{
        cout<<"Pocha Dim"<<'\n';
    }

    return 0;
}