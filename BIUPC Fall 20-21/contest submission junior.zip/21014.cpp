#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <sstream>
#include <queue>
#include <deque>
#include <bitset>
#include <iterator>
#include <list>
#include <stack>
#include <map>
#include <set>
#include <functional>
#include <numeric>
#include <utility>
#include <limits>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

using namespace std;

typedef long int int32;
typedef unsigned long int uint32;
typedef long long int int64;
typedef unsigned long long int uint64;
#define lld long long int
#define INF (int)1e9
#define EPS 1e-9
#define PI 3.1415926535897932384626433832795
#define mXs 1e6
const double pi = acos(-1.0);

int main()
{
    ios_base::sync_with_stdio(false);
    lld n;
    cin >> n;
    if (n == 39 || n == 40 ||n == 41 ||n == 42)
    {
        cout << "Senior division\n";
    }
    else if (n == 43 || n == 44 ||n == 45 ||n == 46)
    {
        cout << "Junior division\n";
    }
    else
    {
        cout << "Out of the division\n";
    }
    //main();
    return 0;
}