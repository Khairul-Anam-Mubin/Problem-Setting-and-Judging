#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number, test, i;
    scanf("%d", &test);
    for(i=0; i<test; i++){
        scanf("%d", &number);
        if(number%18==0){
            printf("YES\n");
        }
        else
            printf("NO\n");
    }
    return 0;
}