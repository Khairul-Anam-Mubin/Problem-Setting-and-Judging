#include<stdio.h>

int main()
{
    int input;
    scanf("%d",&input);
    if ( 18 % input == 0 && 1 <= input <= 100)
    {
     printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }

        return 0;

}