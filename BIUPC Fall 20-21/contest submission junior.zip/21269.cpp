#include <bits/stdc++.h>
#include <string.h>
using namespace std;

int main()
{
    long long int t,feet,inc;
    cin >> t;
    int sum=0,sum1=0;

    while(t--){
        double s;
        cin >> s;
        inc =(s-(int)s)*10 ,feet=(int)s;
        sum +=feet;
        sum1 +=inc;

     if(sum1>=12){
         sum++;
         sum1=sum1%12;
     }
        cout <<sum<<" Feet, "<<sum1<<" Inches"<<endl;

    }

    return 0;
}